// ============ App：同一宇宙 · 双端入口 ============

import { useState } from 'react'
import { CandidateView } from './views/CandidateView'
import { EmployerView } from './views/EmployerView'
import { load, save, clearAll } from './lib/storage'
import type { End } from './types'

function loadCredits(): string[] {
  return load<string[]>('credits', [])
}

export function App() {
  const [end, setEnd] = useState<End>(() => load<End>('end', 'candidate'))
  const [credits, setCredits] = useState<string[]>(loadCredits)
  const [resetN, setResetN] = useState(0)

  const recordCredit = (credit: string) => {
    const next = credits.includes(credit) ? credits : credits.concat(credit)
    setCredits(next)
    save('credits', next)
  }

  const switchEnd = (next: End) => {
    save('end', next)
    setEnd(next)
  }

  const reset = () => {
    clearAll()
    setCredits([])
    save('end', 'candidate')
    setEnd('candidate')
    setResetN((n) => n + 1)
  }

  return (
    <>
      <div className="topbar">
        <div className="topbar-in">
          <div className="brand">
            <span className="mark">宇</span>
            Talentverse
          </div>
          <div className="endswitch" role="tablist" aria-label="切换端">
            <button className={end === 'candidate' ? 'on' : ''} onClick={() => switchEnd('candidate')}>
              候选端 · 证明我行
            </button>
            <button className={end === 'employer' ? 'on' : ''} onClick={() => switchEnd('employer')}>
              雇主端 · 敢用的人
            </button>
          </div>
          <button
            onClick={reset}
            title="清空演示进度，回到开场"
            aria-label="重置演示"
            style={{ fontSize: 12, color: 'var(--text-3)', marginLeft: 4, padding: '4px 8px', border: '1px solid var(--hairline)', borderRadius: 'var(--r-pill)' }}
          >
            重置
          </button>
          <div className="universe-note" style={{ marginLeft: 'auto' }}>
            同一内核 · 两种入口 · 档案两端共用
          </div>
        </div>
      </div>

      {end === 'candidate' ? (
        <CandidateView key={`cand-${resetN}`} credits={credits} />
      ) : (
        <EmployerView key={`emp-${resetN}`} onCredit={recordCredit} onSwitch={switchEnd} />
      )}

      <div className="legal">
        <b>口径与边界（原样呈现）：</b>"已验证" = 候选人本人授权 + 自产证据 + AI 辅助评估与真人多轮技术验证 + 人工复核终审；不等于背调，也不等于录用保证。孤证 / 待补不计入已验证，也不在担保内。失败只落"未达本岗"。本原型为演示，不构成录用 / offer / 背调结果的任何保证；具体权利义务以双方签署的《服务委托书》为准。
        <div className="legend">
          <span><span className="badge v" style={{ background: 'var(--teal-100)', color: 'var(--teal-700)' }}>已验证</span> 敢背书 · 有源可核</span>
          <span><span className="badge ss">强孤证</span> 有署名时间线 · 差第二方一句</span>
          <span><span className="badge s">孤证</span> 只有自述 · 不背书</span>
          <span><span className="badge p">待补</span> 补料即点亮</span>
          <span><span style={{ color: 'var(--seal)', fontWeight: 600 }}>保</span> 试用不符可退换（仅对已验证部分）</span>
        </div>
      </div>
    </>
  )
}
