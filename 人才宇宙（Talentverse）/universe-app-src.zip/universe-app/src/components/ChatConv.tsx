// ============ 对话容器：状态机 + 消息播放 + Composer（说话 / 拖文件） ============

import { useEffect, useRef, useState, type ChangeEvent, type DragEvent, type KeyboardEvent } from 'react'
import type { Msg } from '../msg'
import type { End } from '../types'
import type { RunResult } from '../engine/flows'
import { load, save } from '../lib/storage'
import {
  ArchiveCard,
  ConclusionCard,
  EmpResultCard,
  NoteCard,
} from './cards'

export interface ChipDef {
  label: string
  act: string
}

export interface ConvCfg {
  persona: { label: string; accent: 'cand' | 'emp' }
  persistKey: string
  greet: Msg[]
  chips: (step: number) => ChipDef[]
  fileHint: (step: number) => { name: string; size: string }
  run: (step: number, act: string) => RunResult
  classifyText: (step: number, text: string) => string
}

interface ConvState {
  step: number
  msgs: Msg[]
}

function isMsg(m: Msg | undefined): m is Msg {
  return m != null
}

// 顶层消息渲染器（避免内联组件）
function MessageNode({ msg, liveCred }: { msg: Msg; liveCred: string[] }) {
  if (msg.kind === 'text') {
    if (msg.role === 'user') {
      return (
        <div className="row user">
          <div className="bubble">{msg.text}</div>
        </div>
      )
    }
    return (
      <div className="row agent">
        <div className="avatar agent">T</div>
        <div className="bubble">{msg.text}</div>
      </div>
    )
  }
  if (msg.kind === 'attach') {
    return (
      <div className="row user">
        <div className="attach">
          <span className="ic">▤</span>
          <div>
            <div className="n">{msg.name}</div>
            <div className="s">{msg.size} · 已接收</div>
          </div>
        </div>
      </div>
    )
  }
  if (msg.kind === 'thinking') {
    return (
      <div className="row agent">
        <div className="avatar agent">T</div>
        <div className="thinking">
          <span className="td"><i /><i /><i /></span>
          {msg.text}
        </div>
      </div>
    )
  }
  if (msg.kind === 'conclusion') {
    return (
      <div className="row agent">
        <div className="avatar agent">T</div>
        <ConclusionCard body={msg.body} />
      </div>
    )
  }
  if (msg.kind === 'archive') {
    return (
      <div className="row agent">
        <div className="avatar agent">T</div>
        <ArchiveCard body={msg.body} liveCred={liveCred} />
      </div>
    )
  }
  if (msg.kind === 'emp') {
    return (
      <div className="row agent">
        <div className="avatar agent" style={{ background: 'var(--ink)' }}>E</div>
        <EmpResultCard body={msg.body} />
      </div>
    )
  }
  if (msg.kind === 'note') {
    return (
      <div className="row agent">
        <div className="avatar agent">T</div>
        <NoteCard em={msg.body.em} text={msg.body.text} />
      </div>
    )
  }
  return null
}

export function ChatConv({
  cfg,
  credits = [],
  onCredit,
  onSwitch,
}: {
  cfg: ConvCfg
  credits?: string[]
  onCredit?: (credit: string) => void
  onSwitch?: (end: End) => void
}) {
  const [state, setState] = useState<ConvState>(() => {
    const stored = load<ConvState | null>(cfg.persistKey, null)
    if (stored && Array.isArray(stored.msgs) && stored.msgs.every(isMsg)) return stored
    return { step: 0, msgs: cfg.greet }
  })
  const [busy, setBusy] = useState(false)
  const [text, setText] = useState('')
  const [dragging, setDragging] = useState(false)
  const pendingTimer = useRef<number | null>(null)
  const fileRef = useRef<HTMLInputElement | null>(null)
  const bottomRef = useRef<HTMLDivElement | null>(null)

  // 持久化镜像
  useEffect(() => {
    save(cfg.persistKey, state)
  }, [cfg.persistKey, state])

  // 卸载清理计时器
  useEffect(() => {
    return () => {
      if (pendingTimer.current != null) window.clearTimeout(pendingTimer.current)
    }
  }, [])

  // 新消息自动滚动到底
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
  }, [state.msgs.length])

  const push = (m: Msg) =>
    setState((prev) => ({ ...prev, msgs: prev.msgs.concat(m) }))

  const playItems = (items: { delay: number; msgs: Msg[] }[]) => {
    setBusy(true)
    let i = 0
    const stepOnce = () => {
      if (i >= items.length) {
        setBusy(false)
        return
      }
      const it = items[i]
      i += 1
      pendingTimer.current = window.setTimeout(() => {
        it.msgs.forEach(push)
        stepOnce()
      }, it.delay)
    }
    stepOnce()
  }

  const submit = (chipAct: string | null, file?: File) => {
    if (busy) return
    const act = chipAct ?? 'text'
    const typed = text.trim()
    const effectiveAct = chipAct == null ? cfg.classifyText(state.step, typed) : chipAct

    // 用户可见行
    if (act === 'attach') {
      const hint = cfg.fileHint(state.step)
      push({
        id: 's' + Math.random().toString(36).slice(2),
        role: 'system',
        kind: 'attach',
        name: file ? file.name : hint.name,
        size: file ? fmtSize(file.size) : hint.size,
      })
    } else if (chipAct != null) {
      const chipLabel = cfg.chips(state.step).find((c) => c.act === chipAct)
      if (chipLabel) push({ id: 'u' + Math.random().toString(36).slice(2), role: 'user', kind: 'text', text: chipLabel.label })
    } else if (typed.length > 0) {
      push({ id: 'u' + Math.random().toString(36).slice(2), role: 'user', kind: 'text', text: typed })
    }

    const result = cfg.run(state.step, effectiveAct)
    if (result.credit != null && onCredit) onCredit(result.credit)
    setState((prev) => ({ ...prev, step: result.next }))
    playItems(result.items)
    if (result.goto != null && onSwitch) onSwitch(result.goto)
    setText('')
    if (fileRef.current) fileRef.current.value = ''
  }

  const chips = busy ? [] : cfg.chips(state.step)

  const onFile = (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    if (f) submit('attach', f)
  }
  const onDrop = (e: DragEvent) => {
    e.preventDefault()
    setDragging(false)
    const f = e.dataTransfer.files?.[0]
    if (f) submit('attach', f)
  }
  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      if (text.trim().length > 0 || chips.length === 0) submit(null)
    }
  }

  return (
    <div>
      <div className="persona-line">
        <span className={`persona-dot ${cfg.persona.accent}`}>{cfg.persona.accent === 'cand' ? '你' : '雇'}</span>
        {cfg.persona.label}
      </div>

      <div className="chat" onDragOver={(e) => { e.preventDefault(); setDragging(true) }} onDragLeave={() => setDragging(false)} onDrop={onDrop}>
        {state.msgs.map((m) => (
          <MessageNode key={m.id} msg={m} liveCred={credits} />
        ))}
        <div ref={bottomRef} />
      </div>

      <div className={`composer${dragging ? ' dragover' : ''}`}>
        <div className="composer-in">
          {chips.length > 0 ? (
            <div className="chips">
              {chips.map((c) => (
                <button key={c.label} className="chip" disabled={busy} onClick={() => submit(c.act)}>
                  {c.act === 'attach' ? <span className="plus">＋</span> : null} {c.label}
                </button>
              ))}
            </div>
          ) : null}
          <div className="box">
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={onKey}
              rows={1}
              placeholder="说一句，或把文件拖进来…"
              aria-label="对话输入"
            />
            <button
              className="upload"
              aria-label="上传文件"
              onClick={() => fileRef.current?.click()}
            >
              ＋
              <input ref={fileRef} type="file" onChange={onFile} tabIndex={-1} />
            </button>
            <button
              className="send"
              aria-label="发送"
              disabled={busy || text.trim().length === 0}
              onClick={() => submit(null)}
            >
              ↑
            </button>
          </div>
          <div className="composer-hint">拖文件 / 粘贴链接 / 说话，都行 —— 繁杂的部分是这个 agent 的活，不是你的。</div>
        </div>
      </div>
    </div>
  )
}

function fmtSize(bytes: number): string {
  if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
  if (bytes >= 1024) return Math.round(bytes / 1024) + ' KB'
  return bytes + ' B'
}
