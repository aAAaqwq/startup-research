// ============ 雇主端视图（敢签字的寻访顾问） ============

import { ChatConv, type ConvCfg } from '../components/ChatConv'
import { empGreeting, empReply } from '../engine/flows'
import { employerChips } from '../data/universe'
import type { End } from '../types'

export function EmployerView({
  onCredit,
  onSwitch,
}: {
  onCredit: (credit: string) => void
  onSwitch: (end: End) => void
}) {
  const cfg: ConvCfg = {
    persona: { label: '雇主端 · 替你验人的分析台', accent: 'emp' },
    persistKey: 'emp',
    greet: empGreeting(),
    chips: employerChips,
    fileHint: (step) =>
      step === 0 ? { name: 'jd_bi_saas.pdf', size: '380 KB' } : { name: 'jd_bi_saas.pdf', size: '380 KB' },
    run: (step, act) => {
      if (act === 'gocand') return { next: 2, items: [], goto: 'candidate' as End }
      return empReply(step, act)
    },
    classifyText: (step, text) => {
      if (step === 0) return 'attach'
      if (/约面|面|推进/.test(text)) return 'meet'
      if (/补强|出海|升级/.test(text)) return 'upgrade'
      if (/原件|核|证据/.test(text)) return 'verify'
      return 'meet'
    },
  }
  return <ChatConv cfg={cfg} onCredit={onCredit} onSwitch={onSwitch} />
}
