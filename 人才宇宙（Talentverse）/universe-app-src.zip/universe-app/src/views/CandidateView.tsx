// ============ 候选端视图（能力档案整理师） ============

import { ChatConv, type ConvCfg } from '../components/ChatConv'
import { candGreeting, candReply } from '../engine/flows'
import { candidateChips } from '../data/universe'

export function CandidateView({ credits }: { credits: string[] }) {
  const cfg: ConvCfg = {
    persona: { label: '候选端 · 你的能力档案整理师', accent: 'cand' },
    persistKey: 'cand',
    greet: candGreeting(),
    chips: candidateChips,
    fileHint: (step) =>
      step === 0
        ? { name: 'data_dashboard_v2.pdf', size: '2.1 MB' }
        : { name: 'sales_week.png', size: '1.8 MB' },
    run: (step, act) => candReply(step, act, credits),
    classifyText: (step, text) => {
      if (step === 2 && /做过|补过|口径|定义过/.test(text)) return 'yes'
      if (step === 2) return 'no'
      return 'text'
    },
  }
  return <ChatConv cfg={cfg} credits={credits} />
}
